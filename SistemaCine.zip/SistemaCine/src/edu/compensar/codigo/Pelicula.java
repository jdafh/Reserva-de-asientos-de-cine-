
package edu.compensar.codigo;


public class Pelicula {
    private String titulo;
    private int duracion;
    private String clasificacion;

    public Pelicula(String titulo, int duracion, String clasificacion) {
        this.titulo = titulo;
        this.duracion = duracion;
        this.clasificacion = clasificacion;
    }

    public void mostrarInformacion() {
         System.out.println("\u001B[31mPelicula en cartelera: " + titulo + "\u001B[31m" );
        System.out.println("\u001B[31mDuracion: " + duracion + " min\u001B[31m"); 
        System.out.println("\u001B[31mClasificacion: " + clasificacion + "\u001B[31m"); 
    }
}

