
package edu.compensar.codigo;

import java.util.Scanner;

public class Cine {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Pelicula pelicula = new Pelicula("Viajando al futuro", 169, "+15");
        SalaCine sala = new SalaCine(5, 5, pelicula);
        int opcion;

        do {
            System.out.println("\u001B[34m===== CINEMAGICO =====\u001B[34m");
            pelicula.mostrarInformacion();
            System.out.println();
            System.out.println("1. Ver asientos");
            System.out.println("2. Reservar asiento");
            System.out.println("3. Ver informacion de la pelicula");
            System.out.println("4. Mostrar cantidad de asientos libres");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    sala.mostrarAsientos();
                    break;
                case 2:
                    System.out.print("Ingrese la fila (0-4): ");
                    int fila = scanner.nextInt();
                    System.out.print("Ingrese la columna (0-4): ");
                    int columna = scanner.nextInt();
                    sala.reservarAsiento(fila, columna);
                    break;
                case 3:
                    sala.mostrarPelicula();
                    break;
                case 4:
                    int libres = sala.contarAsientosLibres();
                    System.out.println("Cantidad de asientos libres: " + libres);
                    break;
                case 5:
                    System.out.println("Gracias por usar CINEMAGICO");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }

        } while (opcion != 5);

    
    }
}
