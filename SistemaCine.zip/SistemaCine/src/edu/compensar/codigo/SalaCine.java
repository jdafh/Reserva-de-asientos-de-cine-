package edu.compensar.codigo;

public class SalaCine {
    private Asiento[][] asientos;
    private Pelicula pelicula;

    public SalaCine(int filas, int columnas, Pelicula pelicula) {
        this.pelicula = pelicula;
        asientos = new Asiento[filas][columnas];
        
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                asientos[i][j] = new Asiento(i, j, false);
            }
        }
    }

    public void mostrarAsientos() {
    System.out.println("\nEstado actual de la sala:");
    for (int i = 0; i < asientos.length; i++) { 
        for (int j = 0; j < asientos[i].length; j++) { 
            System.out.print(asientos[i][j].estaOcupado() ? "X " : "L ");
        }
        System.out.println();
    }
    System.out.println();
}

    public boolean reservarAsiento(int fila, int columna) {
        if (fila < 0 || fila >= asientos.length || columna < 0 || columna >= asientos[0].length) {
            System.out.println("Asiento fuera de rango.");
            return false;
        }
        if (!asientos[fila][columna].estaOcupado()) {
            asientos[fila][columna].ocupar();
            System.out.println("Asiento reservado correctamente.");
            return true;
        } else {
            System.out.println("El asiento ya está ocupado eliga otro por favor.");
            return false;
        }
    }

    public int contarAsientosLibres() {
        int libres = 0;
        for (Asiento[] fila : asientos) {
            for (Asiento asiento : fila) {
                if (!asiento.estaOcupado()) {
                    libres++;
                }
            }
        }
        return libres;
    }

    public void mostrarPelicula() {
        pelicula.mostrarInformacion();
    }
}
